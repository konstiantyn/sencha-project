Ext.define('Ext.theme.triton.Toolbar', {
    override: 'Ext.Toolbar',
    config: {
        defaultButtonUI: null
    }
});