# theme-triton/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-triton/sass/etc"`, these files
need to be used explicitly.
