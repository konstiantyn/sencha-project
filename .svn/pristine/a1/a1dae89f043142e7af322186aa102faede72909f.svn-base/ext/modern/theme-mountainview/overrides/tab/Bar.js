Ext.define('Ext.theme.mountainview.tab.Bar', {
    override: 'Ext.tab.Bar',

    config: {
        defaults: {
            flex: 1
        }
    }
});