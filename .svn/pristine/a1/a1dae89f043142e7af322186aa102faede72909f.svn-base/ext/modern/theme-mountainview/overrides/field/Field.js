Ext.define('Ext.theme.mountainview.field.Field', {
    override: 'Ext.field.Field',

    config: {
        labelAlign: 'top'
    }
});