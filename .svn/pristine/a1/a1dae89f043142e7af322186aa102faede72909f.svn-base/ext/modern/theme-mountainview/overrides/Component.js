Ext.define('Ext.theme.mountainview.Component', {
    override: 'Ext.Component'
}, function() {
    Ext.namespace('Ext.theme.is').MountainView = true;
    Ext.theme.name = 'MountainView';
});
