Ext.define('Ext.theme.mountainview.field.Toggle', {
    override: 'Ext.field.Toggle',

    config: {
        activeLabel: 'On',
        inactiveLabel: 'Off'
    }
});